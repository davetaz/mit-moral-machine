const TUTOR_TYPE = ENUM([
  'NOTIFY',
  'INLINE',
  'OVERLAY',
  'NONE'
]);

export default TUTOR_TYPE;
