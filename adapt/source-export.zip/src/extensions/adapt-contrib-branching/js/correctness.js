import QuestionModel from 'core/js/models/questionModel';

export function getMMCorrectness(questionModels) {
  const userAnswer = questionModels[0].attributes._userAnswer;
  var direction = "";
  if (userAnswer[0]) {
    direction =  questionModels[0]._childrenCollection.models[0].attributes.direction;
  } else {
    direction = questionModels[0]._childrenCollection.models[1].attributes.direction;
  }
  if (direction == "go straight") {
    return 'incorrect';
  } else {
    return 'correct';
  }
}

export function getCorrectness(model) {
  const questionModels = model.getAllDescendantModels().concat([model]).filter(model => model instanceof QuestionModel);
  if(questionModels[0].attributes._component == "moral-machine-gmcq") {
    return getMMCorrectness(questionModels);
  } else {
  const numberOfCorrect = (questionModels.filter(child => (child.isCorrect()) && !child.get('_isOptional'))).length;
  const numberOfPartlyCorrect = (questionModels.filter(child => (child.isPartlyCorrect()) && !child.get('_isOptional'))).length;
  const isCorrect = questionModels.every(child => child.isCorrect() || child.get('_isOptional'));
  const isPartlyCorrect = (numberOfCorrect > 0) || (numberOfPartlyCorrect > 0);
  return isCorrect ?
    'correct' :
    isPartlyCorrect ?
      'partlyCorrect' :
      'incorrect';
  }
}