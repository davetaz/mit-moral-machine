define(function(require) {

    describe('My fake test', function() {
        
        it('should allow me to lie about a test', function() {
            
            expect(true).to.be(true);
            
        });
    });

});
