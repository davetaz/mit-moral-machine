define([
  'core/js/adapt',
  './adapt-articleExtension'
], function(Adapt) {

});
