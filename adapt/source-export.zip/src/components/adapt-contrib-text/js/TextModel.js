import ComponentModel from 'core/js/models/componentModel';

export default class TextModel extends ComponentModel {}
