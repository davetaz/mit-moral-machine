import McqModel from 'components/adapt-contrib-mcq/js/McqModel';

export default class MoralMachineGmcqModel extends McqModel {
	isCorrect() {
		return true;
	}
	
}
