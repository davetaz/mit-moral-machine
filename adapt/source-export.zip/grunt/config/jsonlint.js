module.exports = {
  src: ['<%= sourcedir %><%= coursedir %>/<%=languages%>/*.<%=jsonext%>']
};
